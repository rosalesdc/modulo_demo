# -*- coding: utf-8 -*-
from . import grados_estudio 
#es importante el orden, es el nombre del archivo
from . import nombre_cuentas_email
from . import autos
from . import personas
#el que se agregó para el ejemplo de herencia
from . import product_inherited
